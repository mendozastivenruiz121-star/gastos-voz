# Gastos por Voz
1. Abre esta carpeta en Android Studio y deja que sincronice Gradle.
2. Run, o Build > Build APK(s).
3. Toca el micrófono, di "compré X, me costó Y", y ve dictando cada compra.
4. "Terminar y guardar el día" guarda la tabla de hoy en el historial.
5. Pestaña Historial: total por mes y detalle por día.
