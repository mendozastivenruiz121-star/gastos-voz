package com.example.gastosvoz

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    // ---------- paleta ----------
    private val BG = Color.parseColor("#0F0E17")
    private val CARD = Color.parseColor("#1E1B2E")
    private val CARD2 = Color.parseColor("#272440")
    private val ACCENT = Color.parseColor("#FF8906")
    private val ACCENT2 = Color.parseColor("#F25F4C")
    private val GREEN = Color.parseColor("#2CB67D")
    private val TX = Color.parseColor("#FFFFFE")
    private val MU = Color.parseColor("#A7A9BE")

    private lateinit var prefs: android.content.SharedPreferences
    private var moneda = "C$"
    private val hoyItems = mutableListOf<Pair<String, Double>>()

    private lateinit var tabCompra: TextView
    private lateinit var tabHist: TextView
    private lateinit var panelCompra: LinearLayout
    private lateinit var panelHist: LinearLayout
    private lateinit var estado: TextView
    private lateinit var itemsBox: LinearLayout
    private lateinit var totalHoy: TextView
    private lateinit var spMoneda: Spinner
    private lateinit var histContainer: LinearLayout

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == RESULT_OK) {
            val texto = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (texto != null) procesar(texto) else estado.text = "No se escuchó nada. Intenta de nuevo."
        } else estado.text = "No se escuchó nada. Intenta de nuevo."
    }
    private val micPermiso = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) lanzarMic() else estado.text = "Necesito permiso del micrófono para dictar."
    }

    private fun pastilla(color: Int, radius: Float = 22f) = GradientDrawable().apply { setColor(color); cornerRadius = radius }
    private fun borde(color: Int, stroke: Int, radius: Float = 22f) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius; setStroke(3, stroke)
    }
    private fun degradado(c1: Int, c2: Int, radius: Float = 100f) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)
    ).apply { cornerRadius = radius }

    private fun titulo(texto: String, size: Float = 16f, color: Int = TX) = TextView(this).apply {
        text = texto; textSize = size; setTypeface(null, Typeface.BOLD); setTextColor(color)
    }
    private fun texto(texto: String, size: Float = 13f, color: Int = MU) = TextView(this).apply {
        text = texto; textSize = size; setTextColor(color)
    }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = pastilla(CARD, 28f)
        setPadding(36, 32, 36, 32)
    }
    private fun lp(top: Int = 20) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, top, 0, 0) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("gastos", MODE_PRIVATE)
        moneda = prefs.getString("moneda", "C$") ?: "C$"

        val scroll = ScrollView(this).apply { setBackgroundColor(BG); isFillViewport = true }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 56, 36, 56) }
        scroll.addView(col)

        val headRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "🎙️"; textSize = 28f; gravity = Gravity.CENTER
            background = degradado(ACCENT, ACCENT2, 100f)
            layoutParams = LinearLayout.LayoutParams(130, 130)
        }
        headRow.addView(logo)
        val headTxt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 0, 0, 0) }
        headTxt.addView(titulo("Gastos por Voz", 21f))
        headTxt.addView(texto("Dicta tu compra y el precio, suma sola", 12.5f))
        headRow.addView(headTxt)
        col.addView(headRow)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = pastilla(CARD, 30f); setPadding(10, 10, 10, 10) }
        tabCompra = pestanaBtn("Comprar") { mostrar(true) }
        tabHist = pestanaBtn("Historial") { mostrar(false) }
        tabs.addView(tabCompra, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tabs.addView(tabHist, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(tabs, lp(28))

        panelCompra = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val micCard = card()
        val mic = TextView(this).apply {
            text = "🎤"; textSize = 40f; gravity = Gravity.CENTER
            background = degradado(ACCENT, ACCENT2, 200f)
            layoutParams = LinearLayout.LayoutParams(190, 190).apply { gravity = Gravity.CENTER }
            setOnClickListener { pedirMic() }
        }
        val micWrap = LinearLayout(this).apply { gravity = Gravity.CENTER; addView(mic) }
        micCard.addView(micWrap)
        micCard.addView(titulo("Toca para dictar", 15f, TX).apply { gravity = Gravity.CENTER; setPadding(0, 20, 0, 0) })
        estado = texto("Di, por ejemplo: «compré pan, me costó 50»").apply { gravity = Gravity.CENTER; setPadding(0, 6, 0, 0) }
        micCard.addView(estado)
        panelCompra.addView(micCard)

        val listaCard = card()
        listaCard.addView(titulo("Tu lista de hoy", 15f))
        itemsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 16, 0, 0) }
        listaCard.addView(itemsBox)
        val totRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 20, 0, 0) }
        totRow.addView(texto("TOTAL DE HOY", 13f, MU).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); gravity = Gravity.CENTER_VERTICAL })
        totalHoy = titulo(moneda + "0.00", 20f, GREEN)
        totRow.addView(totalHoy)
        listaCard.addView(totRow)
        panelCompra.addView(listaCard, lp())

        val finBtn = botonSolido("✅  Terminar y guardar el día", GREEN) { guardarDia() }
        panelCompra.addView(finBtn, lp())
        col.addView(panelCompra)

        panelHist = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val monCard = card()
        monCard.addView(titulo("Moneda", 14f))
        spMoneda = Spinner(this)
        val monedas = arrayOf("C$  Córdobas", "$  Dólares", "Q  Quetzales", "L  Lempiras")
        val simbolos = arrayOf("C$", "$", "Q", "L")
        val ad = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, monedas) {
            override fun getView(pos: Int, cv: View?, parent: ViewGroup): View {
                val v = super.getView(pos, cv, parent) as TextView
                v.setTextColor(TX); v.setBackgroundColor(CARD2); v.setPadding(20, 20, 20, 20); return v
            }
            override fun getDropDownView(pos: Int, cv: View?, parent: ViewGroup): View {
                val v = super.getDropDownView(pos, cv, parent) as TextView
                v.setTextColor(TX); v.setBackgroundColor(CARD2); v.setPadding(20, 20, 20, 20); return v
            }
        }
        spMoneda.adapter = ad
        spMoneda.setSelection(simbolos.indexOf(moneda).coerceAtLeast(0))
        spMoneda.setPadding(16, 16, 16, 16)
        spMoneda.background = borde(CARD2, ACCENT, 16f)
        spMoneda.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                moneda = simbolos[pos]; prefs.edit().putString("moneda", moneda).apply(); renderTodo()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        monCard.addView(spMoneda, lp(14))
        panelHist.addView(monCard)

        histContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        panelHist.addView(histContainer, lp())
        col.addView(panelHist)

        col.addView(texto("Tus compras se guardan solo en este celular. No se envían a ningún servidor.", 11.5f).apply { setPadding(8, 36, 8, 0); gravity = Gravity.CENTER })

        setContentView(scroll)
        marcarPestana(true)
        renderHoy()
    }

    private fun pestanaBtn(txt: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = txt; gravity = Gravity.CENTER; setPadding(0, 26, 0, 26); textSize = 14.5f
        setOnClickListener { onClick() }
    }

    private fun botonSolido(txt: String, color: Int, onClick: () -> Unit): TextView = TextView(this).apply {
        text = txt; gravity = Gravity.CENTER; textSize = 15.5f; setTypeface(null, Typeface.BOLD)
        setTextColor(Color.parseColor("#0F0E17")); background = pastilla(color, 24f); setPadding(0, 32, 0, 32)
        setOnClickListener { onClick() }
    }

    private fun mostrar(compra: Boolean) {
        panelCompra.visibility = if (compra) View.VISIBLE else View.GONE
        panelHist.visibility = if (compra) View.GONE else View.VISIBLE
        marcarPestana(compra)
        if (!compra) renderTodo()
    }

    private fun marcarPestana(compra: Boolean) {
        tabCompra.background = if (compra) pastilla(ACCENT, 22f) else null
        tabCompra.setTextColor(if (compra) Color.parseColor("#0F0E17") else MU)
        tabCompra.setTypeface(null, if (compra) Typeface.BOLD else Typeface.NORMAL)
        tabHist.background = if (!compra) pastilla(ACCENT, 22f) else null
        tabHist.setTextColor(if (!compra) Color.parseColor("#0F0E17") else MU)
        tabHist.setTypeface(null, if (!compra) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun pedirMic() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) lanzarMic()
        else micPermiso.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun lanzarMic() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Di el producto y el precio")
        }
        try { speechLauncher.launch(i) } catch (e: Exception) { estado.text = "Tu celular no tiene dictado por voz instalado." }
    }

    private val numPalabra = mapOf(
        "cero" to 0, "un" to 1, "uno" to 1, "una" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5,
        "seis" to 6, "siete" to 7, "ocho" to 8, "nueve" to 9, "diez" to 10, "once" to 11, "doce" to 12,
        "trece" to 13, "catorce" to 14, "quince" to 15, "veinte" to 20, "treinta" to 30, "cuarenta" to 40,
        "cincuenta" to 50, "sesenta" to 60, "setenta" to 70, "ochenta" to 80, "noventa" to 90,
        "cien" to 100, "ciento" to 100, "doscientos" to 200, "trescientos" to 300, "quinientos" to 500, "mil" to 1000
    )

    private fun precioDePalabras(t: String): Double? {
        val limpio = java.text.Normalizer.normalize(t.lowercase(), java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}"), "")
        var total = 0; var found = false
        limpio.split(Regex("\\s+")).forEach { w -> numPalabra[w]?.let { total += it; found = true } }
        return if (found) total.toDouble() else null
    }

    private fun procesar(textoOriginal: String) {
        val m = Regex("\\d+(?:[.,]\\d+)?").find(textoOriginal)
        val precio = m?.value?.replace(",", ".")?.toDoubleOrNull() ?: precioDePalabras(textoOriginal)
        var nombre = if (m != null) textoOriginal.replace(m.value, " ") else textoOriginal
        nombre = nombre.lowercase()
            .replace(Regex("compr[eé]\\s*"), "").replace(Regex("me\\s*cost[oó]\\s*"), "")
            .replace(Regex("cost[oó]\\s*"), "").replace(Regex("cuesta\\s*"), "")
            .replace(Regex("pesos?"), "").replace(Regex("c[oó]rdobas?"), "")
            .replace(Regex("d[oó]lares?"), "").replace(Regex("quetzales?"), "").replace(Regex("lempiras?"), "")
            .replace(Regex("\\by\\b"), "").trim().replace(Regex("\\s+"), " ")
        if (precio == null || nombre.isBlank()) { estado.text = "No entendí bien. Di por ejemplo: «arroz, 80»"; return }
        nombre = nombre.replaceFirstChar { it.uppercase() }
        hoyItems.add(nombre to precio)
        renderHoy()
        estado.text = "Agregado: $nombre — $moneda${"%.2f".format(precio)}. Toca el micrófono para seguir."
    }

    private val colores = listOf(Color.parseColor("#FF8906"), Color.parseColor("#F25F4C"), Color.parseColor("#2CB67D"), Color.parseColor("#7F5AF0"), Color.parseColor("#3DA9FC"))

    private fun filaProducto(nombre: String, precio: Double, idx: Int, color: Int): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = pastilla(CARD2, 18f); setPadding(24, 20, 20, 20)
        }
        val bola = TextView(this).apply {
            text = nombre.take(1).uppercase(); gravity = Gravity.CENTER; setTextColor(Color.parseColor("#0F0E17"))
            setTypeface(null, Typeface.BOLD); background = pastilla(color, 100f)
            layoutParams = LinearLayout.LayoutParams(72, 72)
        }
        row.addView(bola)
        val txtCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 0, 0, 0) }
        txtCol.addView(titulo(nombre, 14.5f, TX))
        row.addView(txtCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(titulo("$moneda${"%.2f".format(precio)}", 14.5f, TX))
        val del = TextView(this).apply { text = "  ✕"; setTextColor(MU); textSize = 16f; setPadding(14, 0, 4, 0) }
        del.setOnClickListener { hoyItems.removeAt(idx); renderHoy() }
        row.addView(del)
        return row
    }

    private fun renderHoy() {
        itemsBox.removeAllViews()
        if (hoyItems.isEmpty()) itemsBox.addView(texto("Aún no has dictado ninguna compra hoy.", 13f).apply { setPadding(0, 4, 0, 4) })
        hoyItems.forEachIndexed { idx, (n, p) ->
            itemsBox.addView(filaProducto(n, p, idx, colores[idx % colores.size]), lp(if (idx == 0) 0 else 14))
        }
        val tot = hoyItems.sumOf { it.second }
        totalHoy.text = "$moneda${"%.2f".format(tot)}"
    }

    private fun hoyKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    private fun cargarHist(): JSONObject = try { JSONObject(prefs.getString("hist", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    private fun guardarDia() {
        if (hoyItems.isEmpty()) return
        val hist = cargarHist()
        val k = hoyKey()
        val arr = hist.optJSONArray(k) ?: JSONArray()
        hoyItems.forEach { (n, p) -> arr.put(JSONObject().put("n", n).put("p", p)) }
        hist.put(k, arr)
        prefs.edit().putString("hist", hist.toString()).apply()
        hoyItems.clear(); renderHoy()
        estado.text = "Día guardado ✅. Puedes seguir dictando otra compra."
        Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show()
    }

    private fun renderTodo() {
        histContainer.removeAllViews()
        val hist = cargarHist()
        val dias = hist.keys().asSequence().sortedDescending().toList()
        if (dias.isEmpty()) {
            histContainer.addView(card().apply { addView(texto("Todavía no has guardado ningún día.", 13.5f)) }, lp())
            return
        }
        val porMes = linkedMapOf<String, Double>()
        dias.forEach { d ->
            val mes = d.substring(0, 7)
            val arr = hist.getJSONArray(d)
            var s = 0.0; for (i in 0 until arr.length()) s += arr.getJSONObject(i).getDouble("p")
            porMes[mes] = (porMes[mes] ?: 0.0) + s
        }
        val mesCard = card()
        mesCard.addView(titulo("💰 Gasto por mes", 15f))
        val fmtMes = SimpleDateFormat("MMMM yyyy", Locale("es"))
        porMes.keys.sortedDescending().forEach { mes ->
            val nombreMes = try { fmtMes.format(SimpleDateFormat("yyyy-MM", Locale.getDefault()).parse(mes)!!) } catch (e: Exception) { mes }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 14, 0, 14) }
            row.addView(texto(nombreMes.replaceFirstChar { it.uppercase() }, 14f, TX), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(titulo("$moneda${"%.2f".format(porMes[mes] ?: 0.0)}", 15f, GREEN))
            mesCard.addView(row)
        }
        histContainer.addView(mesCard, lp())

        histContainer.addView(titulo("🧾 Detalle por día", 15f).apply { setPadding(4, 32, 0, 0) })
        val fmtDia = SimpleDateFormat("EEEE d 'de' MMMM", Locale("es"))
        dias.forEach { d ->
            val arr = hist.getJSONArray(d)
            var tot = 0.0; val nombres = mutableListOf<String>()
            for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); tot += o.getDouble("p"); nombres.add("${o.getString("n")} · $moneda${"%.2f".format(o.getDouble("p"))}") }
            val dayCard = card()
            val fecha = try { fmtDia.format(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(d)!!) } catch (e: Exception) { d }
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(titulo(fecha.replaceFirstChar { it.uppercase() }, 14f, TX), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            head.addView(titulo("$moneda${"%.2f".format(tot)}", 15f, ACCENT))
            dayCard.addView(head)
            dayCard.addView(texto(nombres.joinToString("   "), 12.5f).apply { setPadding(0, 10, 0, 0) })
            histContainer.addView(dayCard, lp(16))
        }
    }
}
