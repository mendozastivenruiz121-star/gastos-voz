package com.example.gastosvoz

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private val BG = Color.parseColor("#0F0E17")
    private val CARD = Color.parseColor("#1E1B2E")
    private val CARD2 = Color.parseColor("#272440")
    private val ACCENT = Color.parseColor("#FF8906")
    private val ACCENT2 = Color.parseColor("#F25F4C")
    private val MORADO = Color.parseColor("#7F5AF0")
    private val MORADO2 = Color.parseColor("#3DA9FC")
    private val GREEN = Color.parseColor("#2CB67D")
    private val RED = Color.parseColor("#F25F4C")
    private val TX = Color.parseColor("#FFFFFE")
    private val MU = Color.parseColor("#A7A9BE")

    private lateinit var prefs: android.content.SharedPreferences
    private var moneda = "C$"
    private var balance = 0.0
    private val hoyItems = mutableListOf<Pair<String, Double>>()
    private var modoMic = "compra"

    private lateinit var tabCompra: TextView
    private lateinit var tabHist: TextView
    private lateinit var tabPrest: TextView
    private lateinit var panelCompra: LinearLayout
    private lateinit var panelHist: LinearLayout
    private lateinit var panelPrest: LinearLayout
    private lateinit var estado: TextView
    private lateinit var itemsBox: LinearLayout
    private lateinit var totalHoy: TextView
    private lateinit var balanceTxt: TextView
    private lateinit var spMoneda: Spinner
    private lateinit var histContainer: LinearLayout
    private lateinit var estadoPrest: TextView
    private lateinit var prestContainer: LinearLayout
    private lateinit var totalPrestTxt: TextView

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == RESULT_OK) {
            val texto = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (texto == null) {
                if (modoMic == "compra") estado.text = "No se escuchó nada. Intenta de nuevo." else estadoPrest.text = "No se escuchó nada. Intenta de nuevo."
            } else if (modoMic == "compra") procesarCompra(texto) else procesarPrestamo(texto)
        } else {
            if (modoMic == "compra") estado.text = "No se escuchó nada. Intenta de nuevo." else estadoPrest.text = "No se escuchó nada. Intenta de nuevo."
        }
    }
    private val micPermiso = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) lanzarMic() else { if (modoMic == "compra") estado.text = "Necesito permiso del micrófono." else estadoPrest.text = "Necesito permiso del micrófono." }
    }

    private fun pastilla(color: Int, radius: Float = 22f) = GradientDrawable().apply { setColor(color); cornerRadius = radius }
    private fun borde(color: Int, stroke: Int, radius: Float = 22f) = GradientDrawable().apply { setColor(color); cornerRadius = radius; setStroke(3, stroke) }
    private fun degradado(c1: Int, c2: Int, radius: Float = 100f) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply { cornerRadius = radius }
    private fun titulo(t: String, size: Float = 16f, color: Int = TX) = TextView(this).apply { text = t; textSize = size; setTypeface(null, Typeface.BOLD); setTextColor(color) }
    private fun texto(t: String, size: Float = 13f, color: Int = MU) = TextView(this).apply { text = t; textSize = size; setTextColor(color) }
    private fun card(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = pastilla(CARD, 28f); setPadding(36, 32, 36, 32) }
    private fun lp(top: Int = 20) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, top, 0, 0) }
    private fun formato(v: Double) = "$moneda${"%.2f".format(v)}"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("gastos", MODE_PRIVATE)
        moneda = prefs.getString("moneda", "C$") ?: "C$"
        balance = prefs.getString("balance", "0")?.toDoubleOrNull() ?: 0.0

        val scroll = ScrollView(this).apply { setBackgroundColor(BG); isFillViewport = true }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 56, 36, 56) }
        scroll.addView(col)

        val headRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply { text = "🎙️"; textSize = 28f; gravity = Gravity.CENTER; background = degradado(ACCENT, ACCENT2, 100f); layoutParams = LinearLayout.LayoutParams(130, 130) }
        headRow.addView(logo)
        val headTxt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 0, 0, 0) }
        headTxt.addView(titulo("Gastos por Voz", 21f))
        headTxt.addView(texto("Dicta tu compra y el precio, suma sola", 12.5f))
        headRow.addView(headTxt)
        col.addView(headRow)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = pastilla(CARD, 30f); setPadding(8, 8, 8, 8) }
        tabCompra = pestanaBtn("Comprar") { mostrar("compra") }
        tabHist = pestanaBtn("Historial") { mostrar("hist") }
        tabPrest = pestanaBtn("Préstamos") { mostrar("prest") }
        tabs.addView(tabCompra, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tabs.addView(tabHist, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tabs.addView(tabPrest, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(tabs, lp(28))

        // ===== panel comprar =====
        panelCompra = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val balCard = card()
        val balHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        balHead.addView(texto("💼 BALANCE DISPONIBLE", 12.5f, MU), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        balHead.addView(TextView(this).apply {
            text = "Editar"; setTextColor(Color.parseColor("#0F0E17")); setTypeface(null, Typeface.BOLD); textSize = 12.5f
            background = pastilla(ACCENT, 16f); setPadding(22, 10, 22, 10); setOnClickListener { dialogoBalance() }
        })
        balCard.addView(balHead)
        balanceTxt = titulo(formato(balance), 26f, if (balance >= 0) GREEN else RED).apply { setPadding(0, 10, 0, 0) }
        balCard.addView(balanceTxt)
        panelCompra.addView(balCard)

        val micCard = card()
        val mic = TextView(this).apply {
            text = "🎤"; textSize = 40f; gravity = Gravity.CENTER; background = degradado(ACCENT, ACCENT2, 200f)
            layoutParams = LinearLayout.LayoutParams(190, 190).apply { gravity = Gravity.CENTER }
            setOnClickListener { modoMic = "compra"; pedirMic() }
        }
        micCard.addView(LinearLayout(this).apply { gravity = Gravity.CENTER; addView(mic) })
        micCard.addView(titulo("Toca para dictar", 15f, TX).apply { gravity = Gravity.CENTER; setPadding(0, 20, 0, 0) })
        estado = texto("Di, por ejemplo: «5 libras de papa, 150»").apply { gravity = Gravity.CENTER; setPadding(0, 6, 0, 0) }
        micCard.addView(estado)
        panelCompra.addView(micCard, lp())

        val listaCard = card()
        listaCard.addView(titulo("Tu lista de hoy", 15f))
        itemsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 16, 0, 0) }
        listaCard.addView(itemsBox)
        val totRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 20, 0, 0) }
        totRow.addView(texto("TOTAL DE HOY", 13f, MU).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); gravity = Gravity.CENTER_VERTICAL })
        totalHoy = titulo(formato(0.0), 20f, GREEN)
        totRow.addView(totalHoy)
        listaCard.addView(totRow)
        panelCompra.addView(listaCard, lp())
        panelCompra.addView(botonSolido("✅  Terminar y guardar el día", GREEN) { guardarDia() }, lp())
        col.addView(panelCompra)

        // ===== panel historial =====
        panelHist = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val monCard = card()
        monCard.addView(titulo("Moneda", 14f))
        spMoneda = Spinner(this)
        val monedas = arrayOf("C$  Córdobas", "$  Dólares", "Q  Quetzales", "L  Lempiras")
        val simbolos = arrayOf("C$", "$", "Q", "L")
        val ad = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, monedas) {
            override fun getView(pos: Int, cv: View?, parent: ViewGroup): View { val v = super.getView(pos, cv, parent) as TextView; v.setTextColor(TX); v.setBackgroundColor(CARD2); v.setPadding(20, 20, 20, 20); return v }
            override fun getDropDownView(pos: Int, cv: View?, parent: ViewGroup): View { val v = super.getDropDownView(pos, cv, parent) as TextView; v.setTextColor(TX); v.setBackgroundColor(CARD2); v.setPadding(20, 20, 20, 20); return v }
        }
        spMoneda.adapter = ad
        spMoneda.setSelection(simbolos.indexOf(moneda).coerceAtLeast(0))
        spMoneda.setPadding(16, 16, 16, 16)
        spMoneda.background = borde(CARD2, ACCENT, 16f)
        spMoneda.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { moneda = simbolos[pos]; prefs.edit().putString("moneda", moneda).apply(); renderTodo(); renderBalance(); renderPrestamos() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        monCard.addView(spMoneda, lp(14))
        panelHist.addView(monCard)
        histContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        panelHist.addView(histContainer, lp())
        col.addView(panelHist)

        // ===== panel préstamos =====
        panelPrest = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val prestInfo = card()
        prestInfo.addView(titulo("🤝 Dinero que te deben", 15f))
        prestInfo.addView(texto("Esto es solo un recordatorio. No se resta de tu balance.", 12.5f).apply { setPadding(0, 6, 0, 0) })
        val micPrest = TextView(this).apply {
            text = "🎤"; textSize = 34f; gravity = Gravity.CENTER; background = degradado(MORADO, MORADO2, 200f)
            layoutParams = LinearLayout.LayoutParams(150, 150).apply { gravity = Gravity.CENTER }
            setOnClickListener { modoMic = "prestamo"; pedirMic() }
        }
        prestInfo.addView(LinearLayout(this).apply { gravity = Gravity.CENTER; addView(micPrest) }, lp(18))
        estadoPrest = texto("Di, por ejemplo: «le presté a Juan 200»").apply { gravity = Gravity.CENTER; setPadding(0, 10, 0, 0) }
        prestInfo.addView(estadoPrest)
        prestInfo.addView(botonSolido("✍️  Agregar manualmente", MORADO) { dialogoPrestamoManual() }, lp(16))
        panelPrest.addView(prestInfo)

        val totPrestCard = card()
        val totPRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        totPRow.addView(texto("TE DEBEN EN TOTAL", 13f, MU), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { })
        totalPrestTxt = titulo(formato(0.0), 20f, MORADO)
        totPRow.addView(totalPrestTxt)
        totPrestCard.addView(totPRow)
        panelPrest.addView(totPrestCard, lp())

        prestContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        panelPrest.addView(prestContainer, lp())
        col.addView(panelPrest)

        col.addView(texto("Tus datos se guardan solo en este celular. No se envían a ningún servidor.", 11.5f).apply { setPadding(8, 36, 8, 0); gravity = Gravity.CENTER })

        setContentView(scroll)
        marcarPestana("compra")
        renderHoy()
    }

    private fun dialogoBalance() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText(if (balance != 0.0) balance.toString() else ""); setTextColor(TX); setHintTextColor(MU); hint = "Ej: 2000"; setPadding(24, 24, 24, 24)
        }
        AlertDialog.Builder(this).setTitle("Tu balance disponible").setMessage("Ingresa cuánto dinero tienes ahora mismo")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ -> input.text.toString().replace(",", ".").toDoubleOrNull()?.let { balance = it; guardarBalance(); renderBalance() } }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun guardarBalance() { prefs.edit().putString("balance", balance.toString()).apply() }
    private fun renderBalance() { balanceTxt.text = formato(balance); balanceTxt.setTextColor(if (balance >= 0) GREEN else RED) }

    private fun pestanaBtn(txt: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = txt; gravity = Gravity.CENTER; setPadding(0, 24, 0, 24); textSize = 13.5f; setOnClickListener { onClick() }
    }
    private fun botonSolido(txt: String, color: Int, onClick: () -> Unit): TextView = TextView(this).apply {
        text = txt; gravity = Gravity.CENTER; textSize = 15.5f; setTypeface(null, Typeface.BOLD)
        setTextColor(Color.parseColor("#0F0E17")); background = pastilla(color, 24f); setPadding(0, 32, 0, 32); setOnClickListener { onClick() }
    }

    private fun mostrar(cual: String) {
        panelCompra.visibility = if (cual == "compra") View.VISIBLE else View.GONE
        panelHist.visibility = if (cual == "hist") View.VISIBLE else View.GONE
        panelPrest.visibility = if (cual == "prest") View.VISIBLE else View.GONE
        marcarPestana(cual)
        if (cual == "hist") renderTodo()
        if (cual == "prest") renderPrestamos()
    }

    private fun marcarPestana(cual: String) {
        fun aplicar(v: TextView, on: Boolean) {
            v.background = if (on) pastilla(ACCENT, 20f) else null
            v.setTextColor(if (on) Color.parseColor("#0F0E17") else MU)
            v.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
        }
        aplicar(tabCompra, cual == "compra"); aplicar(tabHist, cual == "hist"); aplicar(tabPrest, cual == "prest")
    }

    private fun pedirMic() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) lanzarMic()
        else micPermiso.launch(Manifest.permission.RECORD_AUDIO)
    }
    private fun lanzarMic() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es")
            putExtra(RecognizerIntent.EXTRA_PROMPT, if (modoMic == "compra") "Di el producto y el precio" else "Di a quién le prestaste y cuánto")
        }
        try { speechLauncher.launch(i) } catch (e: Exception) {
            if (modoMic == "compra") estado.text = "Tu celular no tiene dictado por voz instalado." else estadoPrest.text = "Tu celular no tiene dictado por voz instalado."
        }
    }

    private val numPalabra = mapOf(
        "cero" to 0, "un" to 1, "uno" to 1, "una" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5,
        "seis" to 6, "siete" to 7, "ocho" to 8, "nueve" to 9, "diez" to 10, "once" to 11, "doce" to 12,
        "trece" to 13, "catorce" to 14, "quince" to 15, "veinte" to 20, "treinta" to 30, "cuarenta" to 40,
        "cincuenta" to 50, "sesenta" to 60, "setenta" to 70, "ochenta" to 80, "noventa" to 90,
        "cien" to 100, "ciento" to 100, "doscientos" to 200, "trescientos" to 300, "quinientos" to 500, "mil" to 1000
    )
    private fun precioDePalabras(t: String): Double? {
        val limpio = java.text.Normalizer.normalize(t.lowercase(), java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}"), "")
        var total = 0; var found = false
        limpio.split(Regex("\\s+")).forEach { w -> numPalabra[w]?.let { total += it; found = true } }
        return if (found) total.toDouble() else null
    }

    // Toma el ÚLTIMO número de la frase como el monto (la cantidad suele decirse primero, el precio al final).
    private fun extraerMontoYNombre(textoOriginal: String, fillersExtra: List<Regex>): Pair<Double?, String> {
        val matches = Regex("\\d+(?:[.,]\\d+)?").findAll(textoOriginal).toList()
        val m = matches.lastOrNull()
        val monto = m?.value?.replace(",", ".")?.toDoubleOrNull() ?: precioDePalabras(textoOriginal)
        var nombre = if (m != null) textoOriginal.removeRange(m.range) else textoOriginal
        nombre = nombre.lowercase()
        val base = listOf(
            Regex("compr[eé]\\s*"), Regex("me\\s*cost[oó]\\s*"), Regex("cost[oó]\\s*"), Regex("cuesta\\s*"),
            Regex("(?i)c\\$"), Regex("pesos?"), Regex("c[oó]rdobas?"), Regex("d[oó]lares?"), Regex("quetzales?"), Regex("lempiras?")
        )
        (base + fillersExtra).forEach { nombre = nombre.replace(it, "") }
        nombre = nombre.replace(Regex("\\by\\b"), "").replace(Regex("\\ba\\b"), "")
            .trim().replace(Regex("\\s+"), " ").replace(Regex(",\\s*$"), "").trim()
        if (nombre.isNotBlank()) nombre = nombre.replaceFirstChar { it.uppercase() }
        return monto to nombre
    }

    private fun procesarCompra(textoOriginal: String) {
        val (precio, nombre) = extraerMontoYNombre(textoOriginal, emptyList())
        if (precio == null || nombre.isBlank()) { estado.text = "No entendí bien. Di por ejemplo: «arroz, 80»"; return }
        hoyItems.add(nombre to precio)
        balance -= precio; guardarBalance(); renderBalance()
        renderHoy()
        estado.text = "Agregado: $nombre — ${formato(precio)}. Toca el micrófono para seguir."
    }

    private fun procesarPrestamo(textoOriginal: String) {
        val fillers = listOf(Regex("le\\s*prest[eé]\\s*"), Regex("prest[eé]\\s*"), Regex("me\\s*debe\\s*"), Regex("debe\\s*"), Regex("presto\\s*"))
        val (monto, nombre) = extraerMontoYNombre(textoOriginal, fillers)
        if (monto == null || nombre.isBlank()) { estadoPrest.text = "No entendí bien. Di por ejemplo: «Juan, 200»"; return }
        val arr = cargarPrestamos()
        arr.put(JSONObject().put("n", nombre).put("m", monto).put("f", hoyKey()))
        guardarPrestamos(arr)
        renderPrestamos()
        estadoPrest.text = "Agregado: $nombre te debe ${formato(monto)}. Toca el micrófono para seguir."
    }

    private fun dialogoPrestamoManual() {
        val nIn = EditText(this).apply { hint = "Nombre (ej: Juan)"; setTextColor(TX); setHintTextColor(MU); setPadding(24, 20, 24, 20) }
        val mIn = EditText(this).apply { hint = "Monto (ej: 200)"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; setTextColor(TX); setHintTextColor(MU); setPadding(24, 20, 24, 20) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(nIn); addView(mIn) }
        AlertDialog.Builder(this).setTitle("Nuevo préstamo").setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val n = nIn.text.toString().trim(); val m = mIn.text.toString().replace(",", ".").toDoubleOrNull()
                if (n.isNotBlank() && m != null) {
                    val arr = cargarPrestamos(); arr.put(JSONObject().put("n", n).put("m", m).put("f", hoyKey())); guardarPrestamos(arr); renderPrestamos()
                }
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun cargarPrestamos(): JSONArray = try { JSONArray(prefs.getString("prestamos", "[]") ?: "[]") } catch (e: Exception) { JSONArray() }
    private fun guardarPrestamos(arr: JSONArray) { prefs.edit().putString("prestamos", arr.toString()).apply() }

    private fun renderPrestamos() {
        prestContainer.removeAllViews()
        val arr = cargarPrestamos()
        var total = 0.0
        if (arr.length() == 0) {
            prestContainer.addView(card().apply { addView(texto("No tienes préstamos pendientes.", 13.5f)) })
        } else {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i); val monto = o.getDouble("m"); total += monto
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = pastilla(CARD2, 18f); setPadding(24, 20, 20, 20) }
                val bola = TextView(this).apply { text = o.getString("n").take(1).uppercase(); gravity = Gravity.CENTER; setTextColor(Color.parseColor("#0F0E17")); setTypeface(null, Typeface.BOLD); background = pastilla(MORADO, 100f); layoutParams = LinearLayout.LayoutParams(72, 72) }
                row.addView(bola)
                val col2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 0, 0, 0) }
                col2.addView(titulo(o.getString("n"), 14.5f, TX))
                col2.addView(texto("Te debe", 11.5f))
                row.addView(col2, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(titulo(formato(monto), 14.5f, MORADO))
                val pagado = TextView(this).apply { text = "  ✓"; setTextColor(GREEN); textSize = 18f; setPadding(16, 0, 4, 0) }
                pagado.setOnClickListener { eliminarPrestamo(i, "Marcado como pagado.") }
                row.addView(pagado)
                val del = TextView(this).apply { text = " ✕"; setTextColor(MU); textSize = 16f; setPadding(10, 0, 0, 0) }
                del.setOnClickListener { eliminarPrestamo(i, "Préstamo eliminado.") }
                row.addView(del)
                prestContainer.addView(row, lp(if (i == 0) 0 else 14))
            }
        }
        totalPrestTxt.text = formato(total)
    }

    private fun eliminarPrestamo(idx: Int, msj: String) {
        val arr = cargarPrestamos()
        val nuevo = JSONArray()
        for (i in 0 until arr.length()) if (i != idx) nuevo.put(arr.get(i))
        guardarPrestamos(nuevo); renderPrestamos()
        estadoPrest.text = msj
    }

    private val colores = listOf(Color.parseColor("#FF8906"), Color.parseColor("#F25F4C"), Color.parseColor("#2CB67D"), Color.parseColor("#7F5AF0"), Color.parseColor("#3DA9FC"))

    private fun filaProducto(nombre: String, precio: Double, idx: Int, color: Int): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = pastilla(CARD2, 18f); setPadding(24, 20, 20, 20) }
        row.addView(TextView(this).apply { text = nombre.take(1).uppercase(); gravity = Gravity.CENTER; setTextColor(Color.parseColor("#0F0E17")); setTypeface(null, Typeface.BOLD); background = pastilla(color, 100f); layoutParams = LinearLayout.LayoutParams(72, 72) })
        val txtCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 0, 0, 0) }
        txtCol.addView(titulo(nombre, 14.5f, TX))
        row.addView(txtCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(titulo(formato(precio), 14.5f, TX))
        val del = TextView(this).apply { text = "  ✕"; setTextColor(MU); textSize = 16f; setPadding(14, 0, 4, 0) }
        del.setOnClickListener { hoyItems.removeAt(idx); balance += precio; guardarBalance(); renderBalance(); renderHoy() }
        row.addView(del)
        return row
    }

    private fun renderHoy() {
        itemsBox.removeAllViews()
        if (hoyItems.isEmpty()) itemsBox.addView(texto("Aún no has dictado ninguna compra hoy.", 13f).apply { setPadding(0, 4, 0, 4) })
        hoyItems.forEachIndexed { idx, (n, p) -> itemsBox.addView(filaProducto(n, p, idx, colores[idx % colores.size]), lp(if (idx == 0) 0 else 14)) }
        totalHoy.text = formato(hoyItems.sumOf { it.second })
    }

    private fun hoyKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    private fun cargarHist(): JSONObject = try { JSONObject(prefs.getString("hist", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
    private fun guardarHist(h: JSONObject) { prefs.edit().putString("hist", h.toString()).apply() }

    private fun guardarDia() {
        if (hoyItems.isEmpty()) return
        val hist = cargarHist(); val k = hoyKey()
        val arr = hist.optJSONArray(k) ?: JSONArray()
        hoyItems.forEach { (n, p) -> arr.put(JSONObject().put("n", n).put("p", p)) }
        hist.put(k, arr); guardarHist(hist)
        hoyItems.clear(); renderHoy()
        estado.text = "Día guardado ✅. Puedes seguir dictando otra compra."
        Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show()
    }

    private fun confirmarEliminarDia(d: String, total: Double) {
        AlertDialog.Builder(this).setTitle("¿Eliminar este día?")
            .setMessage("Se borrará esa lista de compras y se sumará ${formato(total)} de vuelta a tu balance.")
            .setPositiveButton("Eliminar") { _, _ ->
                val hist = cargarHist(); hist.remove(d); guardarHist(hist)
                balance += total; guardarBalance(); renderBalance()
                renderTodo()
                Toast.makeText(this, "Día eliminado", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun renderTodo() {
        histContainer.removeAllViews()
        val hist = cargarHist()
        val dias = hist.keys().asSequence().sortedDescending().toList()
        if (dias.isEmpty()) { histContainer.addView(card().apply { addView(texto("Todavía no has guardado ningún día.", 13.5f)) }, lp()); return }
        val porMes = linkedMapOf<String, Double>()
        dias.forEach { d -> val mes = d.substring(0, 7); val arr = hist.getJSONArray(d); var s = 0.0; for (i in 0 until arr.length()) s += arr.getJSONObject(i).getDouble("p"); porMes[mes] = (porMes[mes] ?: 0.0) + s }
        val mesCard = card()
        mesCard.addView(titulo("💰 Gasto por mes", 15f))
        val fmtMes = SimpleDateFormat("MMMM yyyy", Locale("es"))
        porMes.keys.sortedDescending().forEach { mes ->
            val nombreMes = try { fmtMes.format(SimpleDateFormat("yyyy-MM", Locale.getDefault()).parse(mes)!!) } catch (e: Exception) { mes }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 14, 0, 14) }
            row.addView(texto(nombreMes.replaceFirstChar { it.uppercase() }, 14f, TX), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(titulo(formato(porMes[mes] ?: 0.0), 15f, GREEN))
            mesCard.addView(row)
        }
        histContainer.addView(mesCard, lp())
        histContainer.addView(titulo("🧾 Detalle por día", 15f).apply { setPadding(4, 32, 0, 0) })
        val fmtDia = SimpleDateFormat("EEEE d 'de' MMMM", Locale("es"))
        dias.forEach { d ->
            val arr = hist.getJSONArray(d)
            var tot = 0.0; val nombres = mutableListOf<String>()
            for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); tot += o.getDouble("p"); nombres.add("${o.getString("n")} · ${formato(o.getDouble("p"))}") }
            val dayCard = card()
            val fecha = try { fmtDia.format(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(d)!!) } catch (e: Exception) { d }
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(titulo(fecha.replaceFirstChar { it.uppercase() }, 14f, TX), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            head.addView(titulo(formato(tot), 15f, ACCENT))
            val trash = TextView(this).apply { text = "  🗑️"; textSize = 15f; setPadding(14, 0, 0, 0) }
            trash.setOnClickListener { confirmarEliminarDia(d, tot) }
            head.addView(trash)
            dayCard.addView(head)
            dayCard.addView(texto(nombres.joinToString("   "), 12.5f).apply { setPadding(0, 10, 0, 0) })
            histContainer.addView(dayCard, lp(16))
        }
    }
}
